﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GestaoProdutos.Domain.Models
{
    public class ItemEstoque
    {
        public int Codigo { get; set; }           // mapeia id_produto
        public string Descricao { get; set; }    // mapeia nome
        public decimal ValorUnitario { get; set; } // mapeia preco
        public int EstoqueAtual { get; set; }    // mapeia quantidade

        // campo extra pra diferenciar
        public decimal ValorTotal => ValorUnitario * EstoqueAtual;
    }
}

﻿using GestaoProdutos.Data.Repositories;
using GestaoProdutos.Domain.Models;
using System;
using System.Collections.Generic;

namespace GestaoProdutos.Services.Services
{
    public class ItemService
    {
        private readonly ItemRepository _repo = new ItemRepository();

        public List<ItemEstoque> ListarTodos() => _repo.ListarTodos();

        public void Cadastrar(ItemEstoque item)
        {
            if (string.IsNullOrWhiteSpace(item.Descricao))
                throw new ArgumentException("Descrição obrigatória");
            if (item.ValorUnitario < 0)
                throw new ArgumentException("Valor inválido");
            if (item.EstoqueAtual < 0)
                item.EstoqueAtual = 0;

            _repo.Adicionar(item);
        }

        public void AdicionarEstoque(int codigo, int quantidade)
        {
            var item = _repo.ObterPorCodigo(codigo) ?? throw new KeyNotFoundException("Item não encontrado");
            item.EstoqueAtual += quantidade;
            _repo.AtualizarEstoque(codigo, item.EstoqueAtual);
        }

        public void RemoverEstoque(int codigo, int quantidade)
        {
            var item = _repo.ObterPorCodigo(codigo) ?? throw new KeyNotFoundException("Item não encontrado");
            if (item.EstoqueAtual - quantidade < 0)
                throw new InvalidOperationException("Quantidade insuficiente");
            item.EstoqueAtual -= quantidade;
            _repo.AtualizarEstoque(codigo, item.EstoqueAtual);
        }
    }
}

﻿using GestaoProdutos.Domain.Models;
using GestaoProdutos.Data.Db;
using Npgsql;
using System.Collections.Generic;

namespace GestaoProdutos.Data.Repositories
{
    public class ItemRepository
    {
        private readonly DbHelper _db = new DbHelper();

        public List<ItemEstoque> ListarTodos()
        {
            var list = new List<ItemEstoque>();
            using (var conn = _db.GetConnection())
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand("SELECT id_produto, nome, preco, quantidade FROM produto", conn))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(new ItemEstoque
                            {
                                Codigo = reader.GetInt32(0),
                                Descricao = reader.GetString(1),
                                ValorUnitario = reader.GetDecimal(2),
                                EstoqueAtual = reader.GetInt32(3)
                            });
                        }
                    }
                }
            }
            return list;
        }

        public void Adicionar(ItemEstoque item)
        {
            using (var conn = _db.GetConnection())
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand("INSERT INTO produto (nome, preco, quantidade) VALUES (@n, @p, @q)", conn))
                {
                    cmd.Parameters.AddWithValue("n", item.Descricao);
                    cmd.Parameters.AddWithValue("p", item.ValorUnitario);
                    cmd.Parameters.AddWithValue("q", item.EstoqueAtual);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public ItemEstoque ObterPorCodigo(int codigo)
        {
            using (var conn = _db.GetConnection())
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand("SELECT id_produto, nome, preco, quantidade FROM produto WHERE id_produto = @id", conn))
                {
                    cmd.Parameters.AddWithValue("id", codigo);
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new ItemEstoque
                            {
                                Codigo = reader.GetInt32(0),
                                Descricao = reader.GetString(1),
                                ValorUnitario = reader.GetDecimal(2),
                                EstoqueAtual = reader.GetInt32(3)
                            };
                        }
                    }
                }
            }
            return null;
        }

        public void AtualizarEstoque(int codigo, int novaQuantidade)
        {
            using (var conn = _db.GetConnection())
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand("UPDATE produto SET quantidade = @q WHERE id_produto = @id", conn))
                {
                    cmd.Parameters.AddWithValue("q", novaQuantidade);
                    cmd.Parameters.AddWithValue("id", codigo);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}

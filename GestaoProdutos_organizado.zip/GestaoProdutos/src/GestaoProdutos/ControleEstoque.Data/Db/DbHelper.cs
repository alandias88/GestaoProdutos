﻿using Npgsql;
using System.Configuration;

namespace GestaoProdutos.Data.Db
{
    public class DbHelper
    {
        private readonly string _connString;

        public DbHelper()
        {
            _connString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        public NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(_connString);
        }
    }
}

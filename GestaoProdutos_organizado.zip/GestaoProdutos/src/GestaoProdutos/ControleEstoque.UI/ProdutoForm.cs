﻿// arquivo: ItemForm.cs
using GestaoProdutos.Domain.Models;
using System;
using System.Windows.Forms;

namespace GestaoProdutos.AppUI
{
    public partial class ItemForm : Form
    {
        public ItemEstoque Item { get; private set; }

        public ItemForm()
        {
            InitializeComponent();
            // Assegure que os controles no Designer tenham os nomes txtDescricao, numValorUnitario, numEstoque e btnSalvar
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Item = new ItemEstoque
            {
                Descricao = txtDescricao.Text,
                ValorUnitario = numValorUnitario.Value,
                EstoqueAtual = (int)numEstoque.Value
            };
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}

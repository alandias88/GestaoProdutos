﻿// arquivo: MainForm.cs
using GestaoProdutos.Services.Services;
using GestaoProdutos.Domain.Models;
using System;
using System.Windows.Forms;

namespace GestaoProdutos.AppUI
{
    public partial class MainForm : Form
    {
        private ItemService _service;

        public MainForm()
        {
            InitializeComponent();
            _service = new ItemService();
            LoadItens();
        }

        private void LoadItens()
        {
            var itens = _service.ListarTodos();
            dgvItemEstoques.DataSource = itens;
            // ajustar cabeçalhos
            dgvItemEstoques.Columns["Codigo"].HeaderText = "Código";
            dgvItemEstoques.Columns["Descricao"].HeaderText = "Descrição";
            dgvItemEstoques.Columns["ValorUnitario"].HeaderText = "Preço Unitário";
            dgvItemEstoques.Columns["EstoqueAtual"].HeaderText = "Qtd em Estoque";
        }

        private void btnNovoItem_Click(object sender, EventArgs e)
        {
            var f = new ItemForm();
            if (f.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    _service.Cadastrar(f.Item);
                    LoadItens();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnEntradaEstoque_Click(object sender, EventArgs e)
        {
            if (dgvItemEstoques.CurrentRow == null) return;
            int codigo = (int)dgvItemEstoques.CurrentRow.Cells["Codigo"].Value;
            var q = PromptQuantidade("Entrada de estoque:");
            if (q <= 0) return;
            try
            {
                _service.AdicionarEstoque(codigo, q);
                LoadItens();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSaidaEstoque_Click(object sender, EventArgs e)
        {
            if (dgvItemEstoques.CurrentRow == null) return;
            int codigo = (int)dgvItemEstoques.CurrentRow.Cells["Codigo"].Value;
            var q = PromptQuantidade("Saída de estoque:");
            if (q <= 0) return;
            try
            {
                _service.RemoverEstoque(codigo, q);
                LoadItens();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int PromptQuantidade(string titulo)
        {
            using (var f = new Form())
            {
                f.Text = titulo;
                var num = new NumericUpDown { Minimum = 1, Maximum = 10000, Value = 1, Location = new System.Drawing.Point(10, 10) };
                var btnOk = new Button { Text = "OK", DialogResult = DialogResult.OK, Location = new System.Drawing.Point(10, 40) };
                f.Controls.Add(num);
                f.Controls.Add(btnOk);
                f.AcceptButton = btnOk;
                return f.ShowDialog() == DialogResult.OK ? (int)num.Value : 0;
            }
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}

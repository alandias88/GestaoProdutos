﻿namespace GestaoProdutos.AppUI
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvItemEstoques = new System.Windows.Forms.DataGridView();
            this.btnNovoItem = new System.Windows.Forms.Button();
            this.btnEntradaEstoque = new System.Windows.Forms.Button();
            this.btnSaidaEstoque = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemEstoques)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvItemEstoques
            // 
            this.dgvItemEstoques.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvItemEstoques.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItemEstoques.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItemEstoques.Location = new System.Drawing.Point(0, -4);
            this.dgvItemEstoques.Name = "dgvItemEstoques";
            this.dgvItemEstoques.RowHeadersWidth = 51;
            this.dgvItemEstoques.RowTemplate.Height = 24;
            this.dgvItemEstoques.Size = new System.Drawing.Size(481, 371);
            this.dgvItemEstoques.TabIndex = 0;
            // 
            // btnNovoItem
            // 
            this.btnNovoItem.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnNovoItem.Location = new System.Drawing.Point(31, 377);
            this.btnNovoItem.Name = "btnNovoItem";
            this.btnNovoItem.Size = new System.Drawing.Size(120, 38);
            this.btnNovoItem.TabIndex = 1;
            this.btnNovoItem.Text = "Cadastrar";
            this.btnNovoItem.UseVisualStyleBackColor = true;
            this.btnNovoItem.Click += new System.EventHandler(this.btnNovoItem_Click);
            // 
            // btnEntradaEstoque
            // 
            this.btnEntradaEstoque.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnEntradaEstoque.Location = new System.Drawing.Point(156, 377);
            this.btnEntradaEstoque.Name = "btnEntradaEstoque";
            this.btnEntradaEstoque.Size = new System.Drawing.Size(120, 39);
            this.btnEntradaEstoque.TabIndex = 2;
            this.btnEntradaEstoque.Text = "Incrementar";
            this.btnEntradaEstoque.UseVisualStyleBackColor = true;
            this.btnEntradaEstoque.Click += new System.EventHandler(this.btnEntradaEstoque_Click);
            // 
            // btnSaidaEstoque
            // 
            this.btnSaidaEstoque.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSaidaEstoque.Location = new System.Drawing.Point(278, 378);
            this.btnSaidaEstoque.Name = "btnSaidaEstoque";
            this.btnSaidaEstoque.Size = new System.Drawing.Size(120, 40);
            this.btnSaidaEstoque.TabIndex = 3;
            this.btnSaidaEstoque.Text = "Decrementar";
            this.btnSaidaEstoque.UseVisualStyleBackColor = true;
            this.btnSaidaEstoque.Click += new System.EventHandler(this.btnSaidaEstoque_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 453);
            this.Controls.Add(this.btnSaidaEstoque);
            this.Controls.Add(this.btnEntradaEstoque);
            this.Controls.Add(this.btnNovoItem);
            this.Controls.Add(this.dgvItemEstoques);
            this.MinimumSize = new System.Drawing.Size(500, 500);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItemEstoques)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvItemEstoques;
        private System.Windows.Forms.Button btnNovoItem;
        private System.Windows.Forms.Button btnEntradaEstoque;
        private System.Windows.Forms.Button btnSaidaEstoque;
    }
}


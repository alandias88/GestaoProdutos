CREATE TABLE IF NOT EXISTS produto (
    id_produto SERIAL PRIMARY KEY,
    nome VARCHAR(45) NOT NULL,
    preco NUMERIC(10,2) NOT NULL,
    quantidade INT DEFAULT 0
);
